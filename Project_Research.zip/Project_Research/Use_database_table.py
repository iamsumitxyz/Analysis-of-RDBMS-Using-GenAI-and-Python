from Database_table import DatabaseTable
table_name = "employees"
connection_string = "sqlite:///example.db"  # SQLite connection string
db_table = DatabaseTable(table_name, connection_string)
data = db_table.fetch_data()
print(data)
class EmployeeTable(DatabaseTable):
    def __init__(self, connection_string):
        super().__init__('employees', connection_string)
        self.metadata = {
            'table_name': 'employees',
            'description': 'Employee details and payroll information',
            'columns': {
                'id': 'Employee ID',
                'name': 'Employee Name',
                'department': 'Department Name',
                'salary': 'Salary of the Employee'
            }
        }
