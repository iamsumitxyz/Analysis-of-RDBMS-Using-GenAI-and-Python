from Use_database_table import EmployeeTable
import pandasai
from pandasai import SmartDataframe
import os
os.environ['PANDASAI_API_KEY'] = '$2a$10$eSCjrm3l2fnZA.VyYjTHo.JtqjsK0PxgpQX2iL2BdRx.g2ESCEdxe'
def fetch_data_from_table(table_name, connection_string):
    # Initialize the table object and fetch data
    table = EmployeeTable(connection_string)
    return table.fetch_data()
def ask_llm2(question, context):
    sdf = SmartDataframe(context)
    response = sdf.chat(question)
    return response

def main2():
    connection_string = 'sqlite:///example.db'
    table_name = 'employees'
    # Fetch data from the employees table
    context_df = fetch_data_from_table(table_name, connection_string)
    # Ask the LLM a question directly
    question = "Find the highest paid employee with names for each department."
    response = ask_llm2(question, context_df)
    print(response)
if __name__ == "__main__":
    main2()

