import pandas as pd
from transformers import pipeline
from Use_database_table import EmployeeTable
def fetch_data_from_table(table_name, connection_string):
    # Initialize the table object and fetch data
    table = EmployeeTable(connection_string)
    return table.fetch_data()
pipe = pipeline("text-generation", model="gpt2-medium")
def ask_llm(question, context): 
    # Convert context to string 
    context_str = context.to_string(index=False) 
    prompt = f"{question}\n\nContext:\n{context_str}" 
    response = pipe(prompt, max_length=150, num_return_sequences=1, truncation=True) 
    return response[0]['generated_text'] 
def main(): 
    connection_string = 'sqlite:///example.db' 
    table_name = 'employees' 
   # Fetch data from the employees table 
    context_df = fetch_data_from_table(table_name, connection_string) 
   # Ask the LLM a question directly 
    question = "Find the highest paid employee with names for each department." 
    response = ask_llm(question, context_df) 
    print(response) 
if __name__ == "__main__": 
    main() 
